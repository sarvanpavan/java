package genpact.com.Genpact;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class SimpleExcelReaderExample {

	 public static void main(String[] args) throws IOException {
	        String excelFilePath = "D:\\Users\\703163214\\Documents\\New folder\\Writesheet.xlsx";
	        FileInputStream inputStream = new FileInputStream(new File(excelFilePath));
	         
	        Workbook workbook = new XSSFWorkbook(inputStream);
	        Sheet firstSheet = workbook.getSheetAt(0);
	        Iterator<Row> iterator = firstSheet.iterator();
	         String query;
	        while (iterator.hasNext()) {
	            Row nextRow = iterator.next();
	            Iterator<Cell> cellIterator = nextRow.cellIterator();
	             query="create table ram(";
	            while (cellIterator.hasNext()) {
	                Cell cell = cellIterator.next();
	                 
	                switch (cell.getCellType()) {
	                    case Cell.CELL_TYPE_STRING:
	                        System.out.print(cell.getStringCellValue());
	                        query=query+cell.getStringCellValue()+"\t"+"varChar(),";
	                    /*    
	                    case Cell.CELL_TYPE_BOOLEAN:
	                        System.out.print(cell.getBooleanCellValue());
	                        query=query+cell.getStringCellValue()+"/t"+"boolean(),";
	                        
	                    case Cell.CELL_TYPE_NUMERIC:
	                        System.out.print(cell.getNumericCellValue());
	                        query=query+cell.getStringCellValue()+"/t"+"int(),";*/
	                        
	                }
	                query=query.substring(0,query.length()-1)+")";
	                System.out.println(query);
	             
	            }
	          
	        }
	         
	        
	        inputStream.close();
	       /* StringBuilder y=new StringBuilder();
			 String r="insert into saravanan valuees(";
			 y.append(r).append("'"+"ram"+"'"+",").append(23+",");
			 String t=y.toString();
			 t=t.substring(0,t.length()-1);
			 t=t+")";
			 System.out.println(t);*/
	    }
	 
	}