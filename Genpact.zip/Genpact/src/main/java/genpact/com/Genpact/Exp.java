package genpact.com.Genpact;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

public class Exp {
	
	public static void main(String[] args) {
		List<Integer> list = new ArrayList<Integer>();
		list.add(1);
		list.add(2);
		list.add(5);
		list.add(5);
		
		Map<Integer,Integer> map = new Hashtable<Integer,Integer>();
		for(int i=0;i<=list.size()-1;i++){
			
			map.put(list.get(i),i);
			
		}
		
		System.out.println("map :::::"+map.toString());
		System.out.println("list :::::"+list.toString());
		
	}

}
